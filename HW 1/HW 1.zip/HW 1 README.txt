Connor Fong
303991911
CS 174A

Platform: Windows 8.1
Environment: Notepad++
Browser: Mozilla Firefox (32.0.3)

Homework #1:
For this assignment I was able to get WebGL images to display on my screen.  I went through all 4 of 
the various Sierpinski gasket tutorials in the text book and was able to see all of the gasket images
in my web browser.  The gasket I included is the 2nd, because the slides said to turn 
in the 2D gasket.  I included the files for the 1st, 3rd, and 4th gaskets in the folder labelled "Extra."
I attempted to implement the color change on keypress, but was unable to complete this extra credit before
the due date.  The .js file is called "SierpinskiExtra", also in the "Extra" folder.