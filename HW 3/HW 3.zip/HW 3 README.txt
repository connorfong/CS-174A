Connor Fong
303991911
CS 174A

Platform: Windows 8.1
Environment: Notepad++
Browser: Mozilla Firefox (32.0.3)

Homework #1:
For this assignment I displayed displayed all of the planets, including the sun as a point light source.
I used the specified methods of shading the planets, and have the same control scheme, as listed below.
However, I was unsure of how to get the sun to look like anything other than a sphere, and I was unable
to get the camera to rotate, using the 'left' and 'right' arrows.  I used a Phong shader on planets 3 and 4,
and attempter to create a moon, but was unable to finish in time.


'up', 'down', 'left', and 'right' moves the camera in the corresponding direction.
Movement of the camera on the y axis is simulated by translating the spheres in the 
opposite direction of the arrow pressed.  The heading is changed by moving the eye.
'i' and 'm', the camera moves forward or backward.  
'j' and 'k' moves the camera left and right, by translating the planets the opposite direction.
'r' resets the camera and colors of the cubes to the original format.

'n' and 'w' change the aspect ratio specified in the perspective function.