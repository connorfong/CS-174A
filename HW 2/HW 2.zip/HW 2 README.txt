Connor Fong
303991911
CS 174A

Platform: Windows 8.1
Environment: Notepad++
Browser: Mozilla Firefox (32.0.3)

Homework #1:
For this assignment I displayed 8 cubes, each a different color, 
on the screen each a distance +-10 in each axis from the origin.  
The initial camera position encompasses all of the cubes.  
The cubes change color if the 'C' key is pressed.


'up', 'down', 'left', and 'right' moves the camera in the corresponding direction.
Movement of the camera on the y axis is simulated by translating the cubes in the 
opposite direction of the arrow pressed.  The heading is changed by moving the eye.
'i' and 'm', the camera moves forward or backward.  
'j' and 'k' moves the camera left and right, by translating the cubes the opposite direction.
'r' resets the camera and colors of the cubes to the original format.

'n' and 'w' change the aspect ratio specified in the perspective function.
I did not have time to fully implement the code for the crosshair, I have commented the code 
that I was working on for the crosshair in the included files.  